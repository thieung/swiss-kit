# Responsive Design and Dark Mode

## Mobile-First Breakpoints

Default breakpoints:
- **sm:** 640px (mobile landscape)
- **md:** 768px (tablet)
- **lg:** 1024px (laptop)
- **xl:** 1280px (desktop)

**Usage:**
```html
<div class="text-base sm:text-lg md:text-xl lg:text-2xl">
  Responsive text
</div>

<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
  Responsive grid
</div>
```

## Container Queries

Enable components to respond to parent width:

```html
<div class="@container">
  <div class="flex flex-col @md:flex-row @lg:gap-8">
    <div class="@md:w-1/2">Content</div>
  </div>
</div>
```

**Container query modifiers:**
- `@sm:` - min-width: 20rem
- `@md:` - min-width: 28rem
- `@lg:` - min-width: 32rem
- `@xl:` - min-width: 36rem

## Custom Breakpoints

**Min-width:**
```html
<div class="min-[900px]:grid-cols-3">
```

**Max-width:**
```html
<div class="max-md:text-center">
```

**Range:**
```html
<div class="hidden md:block xl:hidden">
  Visible only on md and lg
</div>
```

## Dark Mode - Automatic

Responds to system preference (default):

```html
<div class="bg-white dark:bg-gray-900
            text-gray-900 dark:text-white">
  Auto dark mode
</div>
```

## Dark Mode - Manual Toggle

**1. Define custom variant:**
```css
@import "tailwindcss";

@custom-variant dark (&:where(.dark, .dark *));
```

**2. JavaScript toggle:**
```javascript
// On page load
if (localStorage.theme === 'dark' ||
    (!('theme' in localStorage) &&
     window.matchMedia('(prefers-color-scheme: dark)').matches)) {
  document.documentElement.classList.add('dark')
} else {
  document.documentElement.classList.remove('dark')
}

// Toggle function
function toggleDarkMode() {
  const isDark = document.documentElement.classList.toggle('dark')
  localStorage.theme = isDark ? 'dark' : 'light'
}
```

**3. HTML:**
```html
<html class="dark">
  <body class="bg-white dark:bg-gray-900">
    <button onclick="toggleDarkMode()">
      Toggle Dark Mode
    </button>
  </body>
</html>
```

## Dark Mode Patterns

**Background and text:**
```html
<div class="bg-white dark:bg-gray-900
            text-gray-900 dark:text-white">
```

**Borders:**
```html
<div class="border-gray-200 dark:border-gray-700">
```

**Shadows:**
```html
<div class="shadow-lg dark:shadow-2xl dark:shadow-gray-900/50">
```

**Images:**
```html
<img class="dark:brightness-75 dark:contrast-125">
```

## Responsive + Dark Mode

Combine breakpoints with dark mode:

```html
<div class="bg-white dark:bg-gray-900
            sm:bg-gray-50 sm:dark:bg-gray-800
            md:bg-gray-100 md:dark:bg-gray-700">
</div>
```

## Complete Example

```html
<div class="@container">
  <article class="bg-white dark:bg-gray-900
                  rounded-lg shadow-lg dark:shadow-2xl
                  p-4 sm:p-6 lg:p-8
                  @md:flex @md:gap-6">

    <img class="w-full @md:w-48 rounded
                dark:brightness-90"
         src="image.jpg">

    <div class="flex-1 mt-4 @md:mt-0">
      <h2 class="text-xl sm:text-2xl lg:text-3xl
                 font-bold
                 text-gray-900 dark:text-white">
        Title
      </h2>

      <p class="mt-2 text-sm sm:text-base
                text-gray-600 dark:text-gray-300">
        Description
      </p>
    </div>
  </article>
</div>
```

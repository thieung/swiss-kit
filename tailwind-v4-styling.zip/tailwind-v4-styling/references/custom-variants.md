# Custom Variants with @custom-variant

## Overview

Register conditional styles for data attributes, ARIA states, and media queries using `@custom-variant` directive.

## Basic Syntax

```css
@import "tailwindcss";

@custom-variant theme-midnight (&:where([data-theme="midnight"] *));
```

**Usage:**
```html
<body data-theme="midnight">
  <div class="theme-midnight:bg-black">
  </div>
</body>
```

## Data Attributes

**Single value:**
```css
@custom-variant loading (&[data-loading="true"]);
```

**Usage:**
```html
<button data-loading="true" class="loading:opacity-50">
  Submit
</button>
```

**Multiple values (word list):**
```css
@custom-variant data-checked (&[data-ui~="checked"]);
```

**Usage:**
```html
<div data-ui="checked selected" class="data-checked:underline">
```

## ARIA States

**Sort direction:**
```css
@custom-variant aria-asc (&[aria-sort="ascending"]);
@custom-variant aria-desc (&[aria-sort="descending"]);
```

**Usage:**
```html
<th aria-sort="ascending" class="aria-asc:rotate-0 aria-desc:rotate-180">
  Name
</th>
```

**Expanded/collapsed:**
```css
@custom-variant expanded (&[aria-expanded="true"]);
@custom-variant collapsed (&[aria-expanded="false"]);
```

**Usage:**
```html
<button aria-expanded="false" class="collapsed:rotate-0 expanded:rotate-90">
  Toggle
</button>
```

## Theme Variants

**Multiple themes:**
```css
@custom-variant theme-dark (&:where([data-theme="dark"] *));
@custom-variant theme-light (&:where([data-theme="light"] *));
@custom-variant theme-midnight (&:where([data-theme="midnight"] *));
```

**Usage:**
```html
<div class="theme-dark:bg-gray-900 theme-light:bg-white theme-midnight:bg-black">
```

## State Combinations

**Active + selected:**
```css
@custom-variant active-selected (&[data-active="true"][data-selected="true"]);
```

**Usage:**
```html
<div data-active="true" data-selected="true"
     class="active-selected:bg-blue-500">
```

## Media Queries

**Orientation:**
```css
@custom-variant tall (@media (min-aspect-ratio: 1/1));
@custom-variant wide (@media (max-aspect-ratio: 1/1));
```

**Usage:**
```html
<div class="tall:flex-col wide:flex-row">
```

**Print mode:**
```css
@custom-variant print (@media print);
```

**Usage:**
```html
<header class="print:hidden">
```

## Descendant Selectors

**Parent state affects children:**
```css
@custom-variant parent-loading (&:where([data-loading="true"] *));
```

**Usage:**
```html
<form data-loading="true">
  <button class="parent-loading:opacity-50">
    Submit
  </button>
</form>
```

## Complete Example

```css
@import "tailwindcss";

@custom-variant theme-dark (&:where([data-theme="dark"] *));
@custom-variant loading (&[data-loading="true"]);
@custom-variant aria-invalid (&[aria-invalid="true"]);
@custom-variant data-selected (&[data-ui~="selected"]);

@theme {
  --color-error: oklch(0.55 0.22 25);
}
```

**Usage:**
```html
<div data-theme="dark">
  <form data-loading="false">
    <input aria-invalid="true"
           class="theme-dark:bg-gray-800
                  aria-invalid:border-error
                  focus:ring-2">
    <button data-loading="true"
            data-ui="selected primary"
            class="loading:opacity-50
                   data-selected:bg-blue-500">
      Submit
    </button>
  </form>
</div>
```

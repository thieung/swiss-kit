# Utility Classes Reference

## Layout

**Display:**
`block`, `inline-block`, `inline`, `flex`, `inline-flex`, `grid`, `inline-grid`, `hidden`

**Flexbox:**
```html
<div class="flex flex-row flex-wrap justify-between items-center gap-4">
```

- Direction: `flex-row`, `flex-col`, `flex-row-reverse`, `flex-col-reverse`
- Wrap: `flex-wrap`, `flex-nowrap`
- Justify: `justify-start`, `justify-center`, `justify-between`, `justify-around`
- Align: `items-start`, `items-center`, `items-end`, `items-stretch`
- Gap: `gap-1` to `gap-96`, `gap-x-4`, `gap-y-2`

**Grid:**
```html
<div class="grid grid-cols-3 grid-rows-2 gap-4">
```

- Columns: `grid-cols-1` to `grid-cols-12`, `grid-cols-none`
- Rows: `grid-rows-1` to `grid-rows-6`
- Span: `col-span-2`, `row-span-3`
- Flow: `grid-flow-row`, `grid-flow-col`

## Spacing

**Padding:**
- All sides: `p-0` to `p-96`
- Horizontal: `px-4` (left + right)
- Vertical: `py-4` (top + bottom)
- Individual: `pt-2`, `pr-3`, `pb-4`, `pl-1`

**Margin:**
- All sides: `m-0` to `m-96`
- Horizontal: `mx-4`, `mx-auto` (center)
- Vertical: `my-4`
- Individual: `mt-2`, `mr-3`, `mb-4`, `ml-1`
- Negative: `-mt-4`, `-mx-2`

**Spacing scale:**
`1` = 0.25rem, `2` = 0.5rem, `4` = 1rem, `8` = 2rem, `12` = 3rem, `16` = 4rem

## Typography

**Font Size:**
```html
<p class="text-xs sm:text-sm md:text-base lg:text-lg xl:text-xl">
```

Scale: `text-xs`, `text-sm`, `text-base`, `text-lg`, `text-xl`, `text-2xl`, `text-3xl`, `text-4xl`, `text-5xl`, `text-6xl`, `text-7xl`, `text-8xl`, `text-9xl`

**Font Weight:**
`font-thin`, `font-light`, `font-normal`, `font-medium`, `font-semibold`, `font-bold`, `font-extrabold`

**Line Height:**
`leading-none`, `leading-tight`, `leading-snug`, `leading-normal`, `leading-relaxed`, `leading-loose`

**Letter Spacing:**
`tracking-tighter`, `tracking-tight`, `tracking-normal`, `tracking-wide`, `tracking-wider`, `tracking-widest`

**Text Alignment:**
`text-left`, `text-center`, `text-right`, `text-justify`

**Text Transform:**
`uppercase`, `lowercase`, `capitalize`, `normal-case`

**Text Decoration:**
`underline`, `line-through`, `no-underline`, `overline`

## Colors

**Background:**
```html
<div class="bg-sky-500 bg-opacity-75">
```

**Text:**
```html
<p class="text-gray-900 dark:text-white">
```

**Border:**
```html
<div class="border-gray-300">
```

**Color scale:**
Each color has 11 shades: 50, 100, 200, 300, 400, 500, 600, 700, 800, 900, 950

**Default colors:**
gray, red, orange, amber, yellow, lime, green, emerald, teal, cyan, sky, blue, indigo, violet, purple, fuchsia, pink, rose

## Borders

**Width:**
`border`, `border-0`, `border-2`, `border-4`, `border-8`
`border-t-2`, `border-r-4`, `border-b-2`, `border-l-0`

**Radius:**
`rounded-none`, `rounded-sm`, `rounded`, `rounded-md`, `rounded-lg`, `rounded-xl`, `rounded-2xl`, `rounded-3xl`, `rounded-full`
`rounded-t-lg`, `rounded-r-xl`, `rounded-b-none`, `rounded-l-md`

## Shadows

`shadow-sm`, `shadow`, `shadow-md`, `shadow-lg`, `shadow-xl`, `shadow-2xl`, `shadow-inner`, `shadow-none`

## Width & Height

**Width:**
`w-0` to `w-96`, `w-auto`, `w-full`, `w-screen`, `w-min`, `w-max`, `w-fit`
`w-1/2`, `w-1/3`, `w-2/3`, `w-1/4`, `w-3/4`

**Height:**
`h-0` to `h-96`, `h-auto`, `h-full`, `h-screen`, `h-min`, `h-max`, `h-fit`

**Min/Max:**
`min-w-0`, `min-w-full`, `max-w-xs`, `max-w-sm`, `max-w-md`, `max-w-lg`, `max-w-xl`, `max-w-7xl`

## Opacity

`opacity-0`, `opacity-25`, `opacity-50`, `opacity-75`, `opacity-100`

## Complete Example

```html
<div class="max-w-md mx-auto">
  <article class="bg-white rounded-lg shadow-lg p-6 space-y-4">
    <h2 class="text-2xl font-bold text-gray-900">
      Article Title
    </h2>

    <p class="text-base leading-relaxed text-gray-600">
      Article content with proper spacing and typography.
    </p>

    <div class="flex justify-between items-center pt-4 border-t border-gray-200">
      <button class="px-4 py-2 bg-blue-500 text-white font-semibold rounded hover:bg-blue-600">
        Read More
      </button>
    </div>
  </article>
</div>
```

# Custom Utilities with @utility

## Overview

Register reusable utility classes with variant support using `@utility` directive. Enables creating custom utilities without JavaScript plugins.

## Basic Syntax

```css
@import "tailwindcss";

@utility content-auto {
  content-visibility: auto;
}
```

**Usage:**
```html
<div class="content-auto hover:content-auto">
```

## With Arbitrary Values

**Star syntax for dynamic values:**
```css
@utility tab-* {
  tab-size: --value(--tab-size-*);
}
```

**Usage:**
```html
<pre class="tab-4">Code</pre>
<pre class="tab-8">Indented code</pre>
```

## Theme Values

**Reference theme tokens:**
```css
@utility tab-* {
  tab-size: --value(--tab-size-*);
}
```

**With custom theme:**
```css
@theme {
  --tab-size-github: 8;
  --tab-size-standard: 4;
}

@utility tab-* {
  tab-size: --value(--tab-size-*);
}
```

**Usage:**
```html
<pre class="tab-github">
<pre class="tab-standard">
```

## Multiple Properties

```css
@utility card {
  padding: 1rem;
  border-radius: 0.5rem;
  background-color: white;
  box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
```

**Usage:**
```html
<div class="card hover:shadow-lg">
```

## With Modifiers

**Percentage values:**
```css
@utility opacity-* {
  opacity: --value([percentage]);
  opacity: calc(--value(integer) * 1%);
}
```

**Usage:**
```html
<div class="opacity-50">Half opacity</div>
<div class="opacity-75">75% opacity</div>
```

## Text Line Clamping

```css
@utility line-clamp-* {
  display: -webkit-box;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: --value(integer);
  overflow: hidden;
}
```

**Usage:**
```html
<p class="line-clamp-2">Long text truncated to 2 lines...</p>
<p class="line-clamp-3">Truncated to 3 lines...</p>
```

## Variant Support

All custom utilities automatically support Tailwind variants:

```html
<div class="content-auto hover:content-auto">
<div class="tab-4 md:tab-8">
<div class="dark:card">
<div class="opacity-50 hover:opacity-100">
```

## Advanced Example

```css
@theme {
  --glass-blur: 12px;
  --glass-opacity: 0.8;
}

@utility glass {
  background: rgba(255, 255, 255, var(--glass-opacity));
  backdrop-filter: blur(var(--glass-blur));
  border: 1px solid rgba(255, 255, 255, 0.2);
}

@utility glass-dark {
  background: rgba(0, 0, 0, var(--glass-opacity));
  backdrop-filter: blur(var(--glass-blur));
  border: 1px solid rgba(255, 255, 255, 0.1);
}
```

**Usage:**
```html
<div class="glass dark:glass-dark p-6 rounded-lg">
  Glassmorphism effect
</div>
```

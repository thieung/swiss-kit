# Arbitrary Values Syntax

## Overview

Use bracket notation for one-off custom values without leaving HTML. Enables pixel-perfect designs and CSS variable integration.

## Basic Syntax

**Pixel values:**
```html
<div class="top-[117px] left-[344px]">
```

**Hex colors:**
```html
<div class="bg-[#bada55] text-[#c0ffee]">
```

**Font sizes:**
```html
<p class="text-[22px] leading-[1.8]">
```

## CSS Variables

**Custom properties:**
```html
<div class="bg-(--my-brand-color) text-(--primary-text)">
```

**With fallback:**
```html
<div class="bg-[var(--brand-color,#3b82f6)]">
```

## Complex Values

**Grid columns:**
```html
<div class="grid grid-cols-[1fr_500px_2fr]">
```

**Shadows:**
```html
<div class="shadow-[0_35px_60px_-15px_rgba(0,0,0,0.3)]">
```

**Transforms:**
```html
<div class="translate-x-[calc(100%+1rem)]">
```

## Content Property

**Text content:**
```html
<div class="before:content-['Hello']">
<div class="after:content-['→']">
```

**Unicode:**
```html
<div class="before:content-['\2022']"> <!-- Bullet -->
<div class="after:content-['\00a0']">  <!-- Non-breaking space -->
```

**Empty:**
```html
<div class="before:content-['']">
```

## Type Hints

When CSS variable type is ambiguous, use type hints:

**Length:**
```html
<div class="text-(length:--my-var)">
```

**Color:**
```html
<div class="text-(color:--my-var)">
```

**Percentage:**
```html
<div class="opacity-(percentage:--my-opacity)">
```

## Calc() Expressions

**With custom properties:**
```html
<div class="w-[calc(100%-2rem)]">
<div class="h-[calc(var(--header-height)+1rem)]">
```

**With theme values:**
```html
<div class="p-[calc(theme(spacing.4)*2)]">
```

## URL Values

**Background images:**
```html
<div class="bg-[url('/img/pattern.png')]">
```

**With CSS functions:**
```html
<div class="bg-[linear-gradient(to_right,#f00,#00f)]">
```

## Responsive Arbitrary Values

```html
<div class="top-[117px] lg:top-[344px]">
```

## Arbitrary Properties

Create entirely custom CSS properties:

**Syntax:** `[property:value]`

```html
<div class="[mask-type:luminance]">
<div class="[backdrop-filter:blur(10px)]">
<div class="[@supports(display:grid)]:grid">
```

## With Modifiers

**Opacity:**
```html
<div class="bg-[#3b82f6]/50">
<div class="text-[--primary]/75">
```

**Hover state:**
```html
<div class="hover:bg-[#f0f0f0]">
```

## Complex Gradients

```html
<div class="bg-[linear-gradient(45deg,#667eea_0%,#764ba2_100%)]">

<div class="bg-[radial-gradient(circle_at_center,#fff_0%,#000_100%)]">

<div class="bg-[conic-gradient(from_90deg,red,yellow,green,blue)]">
```

## Grid Template Areas

```html
<div class="[grid-template-areas:'header_header'_'sidebar_main'_'footer_footer']">
```

## Animation Timing

```html
<div class="transition-[cubic-bezier(0.4,0,0.2,1)]">
<div class="duration-[2000ms]">
<div class="delay-[150ms]">
```

## Complete Example

```html
<div class="grid grid-cols-[200px_1fr_300px] gap-[2.5rem]">

  <aside class="bg-(--sidebar-bg) p-[calc(var(--spacing)*4)]">
    <nav class="space-y-[0.875rem]">
      <a class="hover:text-[--accent-color]
                after:content-['']
                after:block
                after:h-[2px]
                after:bg-[--accent-color]
                after:scale-x-0
                hover:after:scale-x-100
                after:transition-transform">
        Link
      </a>
    </nav>
  </aside>

  <main class="min-h-[calc(100vh-var(--header-height))]">
    <div class="bg-[linear-gradient(135deg,#667eea_0%,#764ba2_100%)]
                p-[clamp(1rem,5vw,3rem)]
                rounded-[var(--radius-lg)]">
      Content
    </div>
  </main>

  <aside class="sticky top-[var(--header-height)]
                h-[calc(100vh-var(--header-height))]">
    Sidebar
  </aside>

</div>
```

## Best Practices

1. Use arbitrary values for truly one-off situations
2. Extract repeated arbitrary values to `@theme` or `@utility`
3. Prefer theme values over hardcoded pixels when possible
4. Use type hints for ambiguous CSS variables
5. Combine with variants for responsive and interactive designs

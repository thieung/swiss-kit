# Installation and Setup

## Vite Integration

Install Tailwind CSS v4 with Vite plugin:

```bash
npm install tailwindcss @tailwindcss/vite
```

## Configuration

**vite.config.ts:**
```typescript
import tailwindcss from '@tailwindcss/vite'
import { defineConfig } from 'vite'

export default defineConfig({
  plugins: [tailwindcss()],
})
```

## CSS Import

**In your main CSS file (e.g., app.css):**
```css
@import "tailwindcss";
```

**In HTML head:**
```html
<link rel="stylesheet" href="/src/app.css">
```

## Framework-Specific Setup

**React/Vite:**
```javascript
// main.tsx
import './index.css'
```

**SvelteKit:**
```javascript
// +layout.svelte
<script>
  import '../app.css'
</script>
```

**Vue:**
```javascript
// main.js
import './style.css'
```

## Build Process

Tailwind scans source files for class names at build time, generating only CSS for classes actually used. No additional configuration needed - the Vite plugin handles everything.

## Verification

Test installation:

```html
<h1 class="text-3xl font-bold text-blue-500">
  Hello Tailwind v4!
</h1>
```

If styles apply, installation successful.

## Framework Examples

**Next.js App Router:**
```javascript
// app/layout.tsx
import './globals.css'
```

**Astro:**
```javascript
// astro.config.mjs
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  vite: {
    plugins: [tailwindcss()],
  },
})
```

## Production Build

```bash
npm run build
```

Tailwind automatically purges unused CSS in production builds.

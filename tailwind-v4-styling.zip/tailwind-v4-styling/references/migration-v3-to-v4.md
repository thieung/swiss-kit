# Migration from Tailwind v3 to v4

## Breaking Changes

### 1. CSS-First Configuration

**v3 (JavaScript):**
```javascript
// tailwind.config.js
module.exports = {
  theme: {
    extend: {
      colors: {
        brand: '#3b82f6',
      },
      fontFamily: {
        display: ['Satoshi', 'sans-serif'],
      },
    },
  },
}
```

**v4 (CSS):**
```css
@import "tailwindcss";

@theme {
  --color-brand: #3b82f6;
  --font-display: "Satoshi", "sans-serif";
}
```

### 2. Plugin System

**v3 (JavaScript plugins):**
```javascript
// tailwind.config.js
module.exports = {
  plugins: [
    plugin(function({ addUtilities }) {
      addUtilities({
        '.content-auto': {
          'content-visibility': 'auto',
        },
      })
    }),
  ],
}
```

**v4 (@utility directive):**
```css
@utility content-auto {
  content-visibility: auto;
}
```

### 3. Custom Variants

**v3 (JavaScript):**
```javascript
module.exports = {
  plugins: [
    plugin(function({ addVariant }) {
      addVariant('theme-dark', '&:where([data-theme="dark"] *)')
    }),
  ],
}
```

**v4 (@custom-variant):**
```css
@custom-variant theme-dark (&:where([data-theme="dark"] *));
```

## Installation Changes

**v3:**
```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

**v4:**
```bash
npm install tailwindcss @tailwindcss/vite
```

**v3 PostCSS config:**
```javascript
// postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

**v4 Vite config:**
```javascript
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [tailwindcss()],
})
```

## Import Changes

**v3:**
```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

**v4:**
```css
@import "tailwindcss";
```

## Layer Syntax

**v3:**
```css
@layer components {
  .btn {
    @apply px-4 py-2 bg-blue-500 text-white;
  }
}
```

**v4 (same, but optional):**
```css
@layer components {
  .btn {
    @apply px-4 py-2 bg-blue-500 text-white;
  }
}
```

## Color Tokens

**v3:**
```javascript
theme: {
  extend: {
    colors: {
      primary: {
        400: '#93c5fd',
        500: '#3b82f6',
        600: '#2563eb',
      },
    },
  },
}
```

**v4:**
```css
@theme {
  --color-primary-400: oklch(0.75 0.15 250);
  --color-primary-500: oklch(0.55 0.22 264);
  --color-primary-600: oklch(0.45 0.18 270);
}
```

## Breakpoints

**v3:**
```javascript
theme: {
  extend: {
    screens: {
      '3xl': '1920px',
    },
  },
}
```

**v4:**
```css
@theme {
  --breakpoint-3xl: 120rem;
}
```

## Migration Steps

1. **Install v4:**
   ```bash
   npm install tailwindcss@next @tailwindcss/vite@next
   ```

2. **Update Vite config:**
   ```javascript
   import tailwindcss from '@tailwindcss/vite'

   export default defineConfig({
     plugins: [tailwindcss()],
   })
   ```

3. **Replace CSS imports:**
   ```css
   /* Before */
   @tailwind base;
   @tailwind components;
   @tailwind utilities;

   /* After */
   @import "tailwindcss";
   ```

4. **Convert theme to CSS:**
   - Move `tailwind.config.js` theme to `@theme` in CSS
   - Use OKLCH color space for better color management
   - Convert JavaScript values to CSS custom properties

5. **Convert plugins:**
   - Replace `addUtilities` with `@utility`
   - Replace `addVariant` with `@custom-variant`
   - Remove plugin functions

6. **Test thoroughly:**
   - Check all utilities still work
   - Verify responsive breakpoints
   - Test dark mode
   - Validate custom utilities and variants

7. **Clean up:**
   - Remove `tailwind.config.js` (if fully migrated)
   - Remove `postcss.config.js`
   - Update documentation

## Compatibility Notes

- Most v3 utility classes work unchanged in v4
- Responsive variants unchanged
- State variants unchanged
- Pseudo-elements unchanged
- Arbitrary values syntax unchanged
- Only configuration system changed

## Gradual Migration

You can migrate gradually by keeping both config systems:

```javascript
// tailwind.config.js (v3 style, still supported)
module.exports = {
  theme: {
    extend: {
      // Some config here
    },
  },
}
```

```css
/* app.css (v4 style) */
@import "tailwindcss";

@theme {
  /* Additional config here */
}
```

Both systems merge, allowing incremental migration.

# States and Pseudo-Elements

## Interactive States

**Hover:**
```html
<button class="bg-blue-500 hover:bg-blue-600 hover:scale-105">
  Hover Me
</button>
```

**Focus:**
```html
<input class="border-gray-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200">
```

**Active (click/press):**
```html
<button class="bg-blue-500 active:bg-blue-700 active:scale-95">
  Click Me
</button>
```

**Focus-visible (keyboard only):**
```html
<button class="focus-visible:ring-2 focus-visible:ring-blue-500">
```

## Form States

**Disabled:**
```html
<button disabled class="disabled:opacity-50 disabled:cursor-not-allowed">
  Submit
</button>
```

**Invalid:**
```html
<input required class="invalid:border-red-500 invalid:text-red-600">
```

**Valid:**
```html
<input class="valid:border-green-500">
```

**Required:**
```html
<input class="required:border-gray-400">
```

**Checked (checkbox/radio):**
```html
<input type="checkbox" class="checked:bg-blue-500 checked:border-blue-500">
```

**Indeterminate:**
```html
<input type="checkbox" class="indeterminate:bg-gray-500">
```

## List States

**First child:**
```html
<li class="first:pt-0 first:border-t-0">
```

**Last child:**
```html
<li class="last:pb-0 last:border-b-0">
```

**Odd/Even:**
```html
<tr class="odd:bg-gray-50 even:bg-white">
```

**Only child:**
```html
<div class="only:text-center">
```

## Group States

**Group hover (parent affects child):**
```html
<div class="group">
  <img class="group-hover:scale-110">
  <p class="group-hover:text-blue-500">Hover the parent</p>
</div>
```

**Group focus:**
```html
<div class="group">
  <input class="focus:...">
  <label class="group-focus:text-blue-500">
</div>
```

## Peer States (Sibling)

**Peer invalid:**
```html
<input class="peer" type="email" required>
<p class="peer-invalid:visible invisible text-red-500">
  Invalid email
</p>
```

**Peer checked:**
```html
<input type="checkbox" class="peer">
<label class="peer-checked:text-blue-500">
```

## Has Variant (Parent with children)

**Has checked child:**
```html
<div class="has-checked:bg-blue-50">
  <input type="checkbox">
</div>
```

## Pseudo-Elements

**Before:**
```html
<label class="before:content-['*'] before:text-red-500 before:mr-1">
  Required field
</label>
```

**After:**
```html
<span class="after:content-['→'] after:ml-2">
  Next
</span>
```

**Placeholder:**
```html
<input placeholder="Email" class="placeholder:text-gray-400 placeholder:italic">
```

**File input button:**
```html
<input type="file"
       class="file:mr-4 file:px-4 file:py-2
              file:rounded-full file:border-0
              file:bg-violet-50 file:text-violet-700
              hover:file:bg-violet-100">
```

**Selection:**
```html
<p class="selection:bg-fuchsia-300 selection:text-fuchsia-900">
  Select this text
</p>
```

**Marker (list bullets):**
```html
<ul class="marker:text-blue-500">
  <li>Item</li>
</ul>
```

**First-letter:**
```html
<p class="first-letter:text-7xl first-letter:font-bold first-letter:float-left">
  Drop cap paragraph
</p>
```

**First-line:**
```html
<p class="first-line:uppercase first-line:tracking-widest">
  First line styled differently
</p>
```

## Complete Example

```html
<form class="space-y-4">
  <!-- Email input with validation -->
  <div>
    <label class="after:content-['*'] after:ml-0.5 after:text-red-500">
      Email
    </label>
    <input type="email" required
           class="peer w-full border-gray-300
                  focus:border-blue-500 focus:ring-2 focus:ring-blue-200
                  invalid:border-red-500 invalid:text-red-600
                  placeholder:text-gray-400"
           placeholder="you@example.com">
    <p class="peer-invalid:visible invisible text-sm text-red-500 mt-1">
      Please enter a valid email
    </p>
  </div>

  <!-- Checkbox with label -->
  <div class="has-checked:bg-blue-50 p-2 rounded">
    <input type="checkbox" id="agree" class="peer">
    <label for="agree" class="peer-checked:text-blue-600 peer-checked:font-semibold">
      I agree to the terms
    </label>
  </div>

  <!-- Submit button -->
  <button class="px-6 py-2 bg-blue-500 text-white rounded
                 hover:bg-blue-600 hover:shadow-lg
                 active:bg-blue-700 active:scale-95
                 disabled:opacity-50 disabled:cursor-not-allowed
                 transition-all duration-200">
    Submit
  </button>
</form>
```

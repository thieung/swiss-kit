# Theme Configuration with @theme

## Overview

Define custom design tokens using CSS custom properties in `@theme` directive. Replaces JavaScript configuration from v3.

## Basic Syntax

**In your CSS file:**
```css
@import "tailwindcss";

@theme {
  --font-display: "Satoshi", "sans-serif";
  --color-brand-500: oklch(0.55 0.22 264);
  --breakpoint-3xl: 120rem;
  --spacing-18: calc(var(--spacing) * 18);
  --ease-fluid: cubic-bezier(0.3, 0, 0, 1);
}
```

## Color Tokens

**OKLCH color space (recommended):**
```css
@theme {
  --color-primary-400: oklch(0.75 0.15 250);
  --color-primary-500: oklch(0.55 0.22 264);
  --color-primary-600: oklch(0.45 0.18 270);
}
```

**Hex colors:**
```css
@theme {
  --color-brand: #3b82f6;
  --color-accent: #f59e0b;
}
```

**Usage in HTML:**
```html
<div class="bg-brand-500 text-primary-400">
```

## Typography Tokens

```css
@theme {
  --font-display: "Satoshi", "sans-serif";
  --font-body: "Inter", "system-ui";
  --font-mono: "Fira Code", "monospace";
}
```

**Usage:**
```html
<h1 class="font-display">Title</h1>
<p class="font-body">Body text</p>
```

## Spacing System

```css
@theme {
  --spacing-18: calc(var(--spacing) * 18);
  --spacing-22: calc(var(--spacing) * 22);
}
```

**Usage:**
```html
<div class="p-18 m-22">
```

## Breakpoints

```css
@theme {
  --breakpoint-3xl: 120rem;
  --breakpoint-4xl: 160rem;
}
```

**Usage:**
```html
<div class="3xl:text-6xl 4xl:text-8xl">
```

## Animation Easing

```css
@theme {
  --ease-fluid: cubic-bezier(0.3, 0, 0, 1);
  --ease-bounce: cubic-bezier(0.68, -0.55, 0.265, 1.55);
}
```

**Usage:**
```html
<div class="transition ease-fluid duration-300">
```

## Complete Example

```css
@import "tailwindcss";

@theme {
  /* Colors */
  --color-brand-400: oklch(0.75 0.15 250);
  --color-brand-500: oklch(0.55 0.22 264);
  --color-brand-600: oklch(0.45 0.18 270);

  /* Typography */
  --font-display: "Satoshi", "sans-serif";
  --font-body: "Inter", "system-ui";

  /* Spacing */
  --spacing-18: calc(var(--spacing) * 18);

  /* Breakpoints */
  --breakpoint-3xl: 120rem;

  /* Animations */
  --ease-fluid: cubic-bezier(0.3, 0, 0, 1);
}
```

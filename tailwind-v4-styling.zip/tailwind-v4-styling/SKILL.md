---
name: tailwind-v4-styling
description: Style user interfaces with Tailwind CSS v4.1 utility-first framework. Use when styling components, implementing responsive layouts, adding dark mode, creating custom utilities/variants, configuring design tokens with @theme directive, or migrating from Tailwind v3. Covers installation, configuration, utility classes, responsive design, dark mode, state variants, pseudo-elements, arbitrary values, and CSS-first customization.
---

# Tailwind CSS v4 Styling

## Overview

Tailwind CSS v4.1 introduces CSS-first configuration, enabling rapid UI development with utility classes while maintaining design consistency. Style components using pre-built utilities or create custom ones with `@utility` and `@theme` directives.

## Core Directives

**@theme** - Define custom design tokens in CSS:
```css
@theme {
  --font-display: "Satoshi", "sans-serif";
  --color-brand-500: oklch(0.55 0.22 264);
  --breakpoint-3xl: 120rem;
}
```

**@utility** - Register custom utilities with variant support:
```css
@utility tab-* {
  tab-size: --value(--tab-size-*);
}
```

**@custom-variant** - Create conditional styles:
```css
@custom-variant theme-midnight (&:where([data-theme="midnight"] *));
```

## Quick Reference

**Layout**: `flex`, `grid`, `grid-cols-3`, `gap-4`, `p-4`, `mx-auto`
**Typography**: `text-2xl`, `font-bold`, `leading-tight`, `tracking-wide`
**Colors**: `bg-sky-500`, `text-gray-950`, `border-pink-300`
**Responsive**: `sm:`, `md:`, `lg:`, `xl:`, `@container`
**Dark Mode**: `dark:bg-gray-900`, `dark:text-white`
**States**: `hover:`, `focus:`, `active:`, `disabled:`, `invalid:`
**Pseudo**: `before:`, `after:`, `placeholder:`, `selection:`
**Arbitrary**: `bg-[#bada55]`, `top-[117px]`, `grid-cols-[1fr_500px_2fr]`

## Opacity & Modifiers

Apply transparency: `bg-black/75`, `text-white/90`, `bg-pink-500/[71.37%]`

## Reference Documentation

Load references as needed for specific topics:

| Topic | Reference | Contents |
|-------|-----------|----------|
| Installation & setup | `installation-setup.md` | Vite integration, CSS imports, configuration |
| Theme configuration | `theme-configuration.md` | @theme directive, custom tokens, color spaces |
| Custom utilities | `custom-utilities.md` | @utility directive, arbitrary values, theme values |
| Custom variants | `custom-variants.md` | @custom-variant directive, data attributes, ARIA states |
| Responsive & dark mode | `responsive-dark-mode.md` | Breakpoints, container queries, dark mode toggle |
| Utility classes | `utility-classes.md` | Layout, typography, colors, spacing utilities |
| States & pseudo-elements | `pseudo-states.md` | Form states, interactive states, pseudo-elements |
| Arbitrary values | `arbitrary-values.md` | Bracket notation, CSS variables, type hints |
| Migration guide | `migration-v3-to-v4.md` | v3 to v4 migration, breaking changes |

## Workflow

1. **Identify task**: Styling components, responsive layout, dark mode, custom utilities
2. **Load relevant reference**: Use table above to select appropriate reference file
3. **Apply utilities**: Use utility classes directly in HTML/JSX
4. **Customize as needed**: Create custom utilities/variants or theme tokens
5. **Test responsiveness**: Verify mobile-first breakpoints and dark mode

## Instructions

When styling with Tailwind v4:

1. Use utility classes for rapid styling without custom CSS
2. Apply responsive variants with mobile-first methodology
3. Implement dark mode with `dark:` prefix
4. Create custom utilities only when needed repeatedly
5. Define design tokens in `@theme` for consistency
6. Use arbitrary values for one-off custom styles
7. Leverage container queries for component-level responsiveness

## Documentation Sources

- Official docs: https://tailwindcss.com/docs
- Context7 llms.txt: `https://context7.com/websites/tailwindcss/llms.txt?tokens=10000`
- GitHub: https://github.com/tailwindlabs/tailwindcss
